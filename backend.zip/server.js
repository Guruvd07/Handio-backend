import express from "express";
import cors from "cors";
import compression from "compression";
import helmet from "helmet";
import dotenv from "dotenv";

import connectDB from "./config/db.js";

/* ROUTES */
import providerRoutes from "./routes/providerRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import bookingRoutes from "./routes/bookingRoutes.js";
import reviewRoutes from "./routes/reviewRoutes.js";

dotenv.config();

const app = express();

/* ===========================
   SECURITY & PERFORMANCE
=========================== */

// Important when deployed behind Render proxy
app.set("trust proxy", 1);

// Security headers
app.use(helmet());

// Gzip compression
app.use(compression());

// CORS (restrict in production)
app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "https://handio-frontend.onrender.com"
    ],
    credentials: true
  })
);

app.use(express.json());

/* ===========================
   ROUTES
=========================== */

app.use("/providers", providerRoutes);
app.use("/auth", authRoutes);
app.use("/admin", adminRoutes);
app.use("/bookings", bookingRoutes);
app.use("/api/reviews", reviewRoutes);

/* ===========================
   HEALTH CHECK
=========================== */

app.get("/api/health", (req, res) => {
  res.status(200).json({ status: "OK" });
});

/* Root */

app.get("/", (req, res) => {
  res.send("Handio Backend Running");
});

/* ===========================
   DATABASE
=========================== */

connectDB();

/* ===========================
   SERVER
=========================== */

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});