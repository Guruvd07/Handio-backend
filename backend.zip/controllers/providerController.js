const Provider = require("../models/ProviderProfile");

exports.createProfile = async (req, res) => {
  try {
    const profile = await Provider.create({
      userId: req.user.id,
      category: req.body.category,
      experience: req.body.experience,
      description: req.body.description,
      city: req.body.city,
      area: req.body.area,
      pincode: req.body.pincode,
      price: req.body.price,
    });

    res.json(profile);
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
};

export const uploadPortfolioImage = async (req, res) => {
  try {
 
   const provider = await ProviderProfile.findOne({ userId: req.user.id });
 
   if (!provider) {
    return res.status(404).json({ message: "Provider profile not found" });
   }
 
   const imageUrl = req.file.path;
 
   provider.portfolio.push({
    imageUrl: imageUrl,
    caption: req.body.caption || ""
   });
 
   await provider.save();
 
   res.json({
    message: "Portfolio image uploaded",
    portfolio: provider.portfolio
   });
 
  } catch (error) {
   res.status(500).json({ message: error.message });
  }
 };
